package org.news.restAPI.dto;

/*
 * created by Praveen Mekala
 * on 25-Nov-2018
 *
 */

public class NewsRequestDTO {
	private String category;
	private String country;
	private String filterKeyword;

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getFilterKeyword() {
		return filterKeyword;
	}

	public void setFilterKeyword(String filterKeyword) {
		this.filterKeyword = filterKeyword;
	}
}
