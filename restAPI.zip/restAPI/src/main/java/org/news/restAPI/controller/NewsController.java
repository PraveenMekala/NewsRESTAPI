package org.news.restAPI.controller;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.news.restAPI.constants.NewsRESTConstants;
import org.news.restAPI.dto.NewsRequestDTO;
import org.news.restAPI.dto.NewsResponseDTO;
import org.news.restAPI.exceptionHandler.NewsAPIException;
import org.news.restAPI.service.ESNewsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/*
 * created by Praveen Mekala
 * on 25-Nov-2018
 *
 */

@RestController
public class NewsController {

	@Autowired
	private ESNewsService eSNewsService;

	@Autowired
	private RedisTemplate<Object, Object> redisTemplate;

	public ESNewsService geteSNewsService() {
		return eSNewsService;
	}

	public void seteSNewsService(ESNewsService eSNewsService) {
		this.eSNewsService = eSNewsService;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/news", produces = "application/json")
	@ResponseBody
	public NewsResponseDTO getFilteredNews(@RequestBody NewsRequestDTO newsRequestDTO) {
		String key = generateRedisKey(newsRequestDTO);
		ObjectMapper objectMapper = new ObjectMapper();
		if (redisTemplate.hasKey(key)) {
			String newsResponseJson = (String) redisTemplate.opsForValue().get(key);
			NewsResponseDTO newsResponse = new NewsResponseDTO();
			try {
				newsResponse = objectMapper.readValue(newsResponseJson, NewsResponseDTO.class);
			} catch (IOException e) {
				e.printStackTrace();
				throw new NewsAPIException("Exception while converting redis string value to response object");
			}
			newsResponse.setFromRedis(true);
			return newsResponse;
		}

		NewsResponseDTO newsResponse = eSNewsService.getFilteredNews(newsRequestDTO);
		String newsResponseJson;
		try {
			newsResponseJson = objectMapper.writeValueAsString(newsResponse);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			throw new NewsAPIException("Exception while converting redis string value to response object");
		}
		redisTemplate.opsForValue().set(key, newsResponseJson);
		redisTemplate.expire(key, NewsRESTConstants.REDIS_KEY_TTL, TimeUnit.MINUTES);
		return newsResponse;
	}

	public String generateRedisKey(NewsRequestDTO newsRequestDTO) {
		StringBuffer key = new StringBuffer();
		key.append(newsRequestDTO.getCategory()).append(newsRequestDTO.getCountry())
				.append(newsRequestDTO.getFilterKeyword());
		return key.toString();
	}
}
