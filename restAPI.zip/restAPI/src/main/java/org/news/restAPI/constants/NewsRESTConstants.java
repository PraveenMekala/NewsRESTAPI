package org.news.restAPI.constants;
 
/*
 * created by Praveen Mekala
 * on 25-Nov-2018
 *
 */

public class NewsRESTConstants {
	public static final String APIKEY = "eadb6da4bb5847a8b5f5b8a633e53ab9";
	public static final String ES_BASE_URL = "https://newsapi.org/v2/top-headlines";
	public static final long REDIS_KEY_TTL = 10L;

}
