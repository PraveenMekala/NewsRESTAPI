package org.news.restAPI.dto;

import java.util.List;

/*
 * created by Praveen Mekala
 * on 25-Nov-2018
 *
 */

public class NewsResponseDTO {
	private String country;
	private String category;
	private String filterKeyword;
	private List<NewsResponse> newsResponseList;
	private boolean isFromRedis;

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getFilterKeyword() {
		return filterKeyword;
	}

	public void setFilterKeyword(String filterKeyword) {
		this.filterKeyword = filterKeyword;
	}

	public List<NewsResponse> getNewsResponseList() {
		return newsResponseList;
	}

	public void setNewsResponseList(List<NewsResponse> newsResponseList) {
		this.newsResponseList = newsResponseList;
	}

	public boolean isFromRedis() {
		return isFromRedis;
	}

	public void setFromRedis(boolean isFromRedis) {
		this.isFromRedis = isFromRedis;
	}
}
