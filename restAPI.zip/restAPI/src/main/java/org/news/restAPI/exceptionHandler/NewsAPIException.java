package org.news.restAPI.exceptionHandler;

import org.news.restAPI.dto.ESErrorDTO;

/*
 * created by Praveen Mekala
 * on 25-Nov-2018
 *
 */

public class NewsAPIException extends RuntimeException {
	public NewsAPIException(String message) {
		super(message);
	}
}
