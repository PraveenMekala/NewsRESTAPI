package org.news.restAPI.exceptionHandler;
 
/*
 * created by Praveen Mekala
 * on 25-Nov-2018
 *
 */

public class RedisClientException extends RuntimeException {
	public RedisClientException(String message) {
		super(message);
	}
}
