package org.news.restAPI.exceptionHandler;

/*
 * created by Praveen Mekala
 * on 25-Nov-2018
 *
 */

public class InvalidRequestException extends RuntimeException {

	public InvalidRequestException(String message) {
		super(message);
	}

}
