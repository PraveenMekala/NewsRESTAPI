package org.news.restAPI.redis;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisPassword;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

/*
 * created by Praveen Mekala
 * on 25-Nov-2018
 *
 */

@Configuration
public class RedisConfigTemplate {
	@Bean
	JedisConnectionFactory jedisConnectionFactory() {
	    RedisStandaloneConfiguration redisStandaloneConfiguration = new RedisStandaloneConfiguration("18.188.54.212", 6379);
	    //redisStandaloneConfiguration.setPassword(RedisPassword.of("root"));
	    //return new JedisConnectionFactory(redisStandaloneConfiguration);
	    return new JedisConnectionFactory();

	}

	@Bean
	public RedisTemplate<Object, Object> redisTemplate() {
		RedisTemplate<Object, Object> template = new RedisTemplate<>();
		template.setConnectionFactory(jedisConnectionFactory());
		return template;
	}
}
