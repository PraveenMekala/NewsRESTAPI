package org.news.restAPI.dto;

/*
 * created by Praveen Mekala
 * on 25-Nov-2018
 *
 */

public class NewsResponse {
	private String newsTitle;
	private String description;
	private String sourceNewsUrl;

	public String getNewsTitle() {
		return newsTitle;
	}

	public void setNewsTitle(String newsTitle) {
		this.newsTitle = newsTitle;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSourceNewsUrl() {
		return sourceNewsUrl;
	}

	public void setSourceNewsUrl(String sourceNewsUrl) {
		this.sourceNewsUrl = sourceNewsUrl;
	}
}
