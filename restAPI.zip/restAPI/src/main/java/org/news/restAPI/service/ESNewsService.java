package org.news.restAPI.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.http.HttpResponse;
import org.news.restAPI.constants.NewsRESTConstants;
import org.news.restAPI.dto.ESErrorDTO;
import org.news.restAPI.dto.NewsRequestDTO;
import org.news.restAPI.dto.NewsResponse;
import org.news.restAPI.dto.NewsResponseDTO;
import org.news.restAPI.exceptionHandler.InvalidRequestException;
import org.news.restAPI.exceptionHandler.NewsAPIException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/*
 * created by Praveen Mekala
 * on 25-Nov-2018
 *
 */

@Service
public class ESNewsService {
	private static final Logger logger = LoggerFactory.getLogger(ESNewsService.class);

	private MultiThreadedHttpConnectionManager multiThreadedHttpConManager;
	private HttpClient httpClient;

	@PostConstruct
	private void init() {
		multiThreadedHttpConManager = new MultiThreadedHttpConnectionManager();
		logger.info("total connections: " + multiThreadedHttpConManager.getParams().getMaxTotalConnections());
		multiThreadedHttpConManager.getParams().setMaxTotalConnections(25);
		logger.info(
				"total connections after setting: " + multiThreadedHttpConManager.getParams().getMaxTotalConnections());
		httpClient = new HttpClient(multiThreadedHttpConManager);
	}

	public NewsResponseDTO getFilteredNews(NewsRequestDTO newsRequestDTO) {
		String newsResponseJson = sendGetRequest(newsRequestDTO);

		if (newsResponseJson == null)
			throw new NewsAPIException("Unexpected response from given elastic search api");

		NewsResponseDTO newsResponse = new NewsResponseDTO();
		try {
			newsResponse = filterNewsResponseByKeyword(newsResponseJson, newsRequestDTO);
		} catch (Exception e) {
			e.printStackTrace();
			throw new InvalidRequestException("Unexpected error in flitering elastic search response by given keyword");
		}
		return newsResponse;
	}

	public String sendGetRequest(NewsRequestDTO newsRequestDTO) {
		String baseURL = NewsRESTConstants.ES_BASE_URL;
		String queryUrl = "?apiKey=" + NewsRESTConstants.APIKEY;
		if (newsRequestDTO.getCategory() != null)
			queryUrl = queryUrl + "&category=" + newsRequestDTO.getCategory();
		if (newsRequestDTO.getCountry() != null)
			queryUrl = queryUrl + "&country=" + newsRequestDTO.getCountry();
		String requestUrl = baseURL + queryUrl;
		// requestUrl = baseURL + URLEncoder.encode(queryUrl, "UTF-8");

		GetMethod request = new GetMethod(requestUrl);
		String responseLine = "";
		StringBuffer response = new StringBuffer();
		try {
			int responseCode = httpClient.executeMethod(request);
			BufferedReader rd = new BufferedReader(new InputStreamReader(request.getResponseBodyAsStream()));
			while ((responseLine = rd.readLine()) != null) {
				response.append(responseLine);
			}
			String responseStr = new String(response);
			if (responseCode == 200) {
				return responseStr;
			} else {
				ESErrorDTO esErrorDTO = new ObjectMapper().readValue(responseStr, ESErrorDTO.class);
				throw new InvalidRequestException(esErrorDTO.getMessage());
			}
		} catch (IOException e) {
			logger.error("Exception occured in reading ES response. " + e);
			e.printStackTrace();
			throw new InvalidRequestException("Unexpected response from given elastic search api");
		} finally {
			request.releaseConnection();
		}
	}

	public NewsResponseDTO filterNewsResponseByKeyword(String newsResponseJson, NewsRequestDTO newsRequestDTO)
			throws JsonParseException, JsonMappingException, IOException {
		JsonParser parser = new JsonParser();
		JsonObject jsonResponseObject = new JsonObject();
		JsonArray jsonResponseArray = new JsonArray();
		try {
			jsonResponseObject = (JsonObject) parser.parse(newsResponseJson.toString());
			jsonResponseArray = jsonResponseObject.get("articles").getAsJsonArray();
		} catch (Exception e) {
			e.printStackTrace();
			ESErrorDTO esErrorDTO = new ObjectMapper().readValue(newsResponseJson, ESErrorDTO.class);
			throw new NewsAPIException(esErrorDTO.getMessage());
		}
		String keyWord = newsRequestDTO.getFilterKeyword();
		NewsResponseDTO newsResponseDTO = new NewsResponseDTO();
		newsResponseDTO.setCategory(newsRequestDTO.getCategory());
		newsResponseDTO.setCountry(newsRequestDTO.getCountry());
		newsResponseDTO.setFilterKeyword(keyWord);
		newsResponseDTO.setFromRedis(false);
		List<NewsResponse> newsResponseList = new ArrayList<NewsResponse>();

		for (int i = 0; i < jsonResponseArray.size(); i++) {
			JsonObject jsonObject = (JsonObject) jsonResponseArray.get(i);
			String title = String.valueOf(jsonObject.get("title"));
			String description = String.valueOf(jsonObject.get("description"));
			String url = String.valueOf(jsonObject.get("url"));
			String content = String.valueOf(jsonObject.get("content"));
			if (keyWord != null) {
				if (title != null && title.contains(keyWord) || (description != null && description.contains(keyWord))
						|| (content != null && content.contains(keyWord))) {
					NewsResponse newsResponse = new NewsResponse();
					newsResponse.setDescription(description);
					newsResponse.setNewsTitle(title);
					newsResponse.setSourceNewsUrl(url);
					newsResponseList.add(newsResponse);
				}
			} else {
				NewsResponse newsResponse = new NewsResponse();
				newsResponse.setDescription(description);
				newsResponse.setNewsTitle(title);
				newsResponse.setSourceNewsUrl(url);
				newsResponseList.add(newsResponse);
			}
		}
		newsResponseDTO.setNewsResponseList(newsResponseList);
		return newsResponseDTO;
	}
}
