package org.news.restAPI.dto;

/*
 * created by Praveen Mekala
 * on 25-Nov-2018
 *
 */

public class ErrorDTO {
	private Boolean error = false;
	private String message;

	public Boolean getError() {
		return error;
	}

	public void setError(Boolean error) {
		this.error = error;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
