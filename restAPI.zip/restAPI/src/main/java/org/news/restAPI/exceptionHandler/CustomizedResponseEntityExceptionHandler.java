package org.news.restAPI.exceptionHandler;

import org.news.restAPI.dto.ErrorDTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

/*
 * created by Praveen Mekala
 * on 25-Nov-2018
 *
 */

@ControllerAdvice
public class CustomizedResponseEntityExceptionHandler  {


	@ExceptionHandler(InvalidRequestException.class)
	public final ResponseEntity<ErrorDTO> handleInvalidTokenException(InvalidRequestException ex, WebRequest request) {
		ErrorDTO errorDTO = new ErrorDTO();
		errorDTO.setMessage(ex.getMessage());
		errorDTO.setError(true);
		return new ResponseEntity<ErrorDTO>(errorDTO, HttpStatus.BAD_REQUEST);
	}	
	
	@ExceptionHandler(NewsAPIException.class)
	public final ResponseEntity<ErrorDTO> handleNewsAPIException(Exception ex, WebRequest request) {
		ErrorDTO errorDTO = new ErrorDTO();
		errorDTO.setMessage(ex.getMessage());
		errorDTO.setError(true);
		return new ResponseEntity<ErrorDTO>(errorDTO, HttpStatus.SERVICE_UNAVAILABLE);
	}
	
	@ExceptionHandler(Exception.class)
	public final ResponseEntity<ErrorDTO> handleGeneralException(Exception ex, WebRequest request) {
		ErrorDTO errorDTO = new ErrorDTO();
		errorDTO.setMessage(ex.getMessage());
		errorDTO.setError(true);
		return new ResponseEntity<ErrorDTO>(errorDTO, HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
